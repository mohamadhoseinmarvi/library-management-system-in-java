

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `librarydb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `librarydb`;



CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `category` varchar(255) NOT NULL,
  `isbn` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `language` varchar(64) NOT NULL,
  `state` int(11) NOT NULL COMMENT '1 = available\r\n2 = borrowed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



CREATE TABLE `book_lending` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `state` int(11) NOT NULL COMMENT '1 = barrowed 2 = returned'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `id_number` varchar(64) DEFAULT NULL,
  `id_type` varchar(64) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(64) NOT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



CREATE TABLE `users` (
  `full_name` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(64) NOT NULL,
  `nic` varchar(20) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `book_lending`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_lending` (`book_id`),
  ADD KEY `member_lending` (`member_id`);

ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`user_name`);


ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `book_lending`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `book_lending`
  ADD CONSTRAINT `book_lending` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `member_lending` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`);
COMMIT;
