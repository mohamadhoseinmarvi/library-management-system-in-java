
package DB;

public class Members extends Database {
    @Override
    public String getTableName(){
            return "members";
    }
}
