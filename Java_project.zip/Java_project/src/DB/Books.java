
package DB;

public class Books extends Database{
    @Override
    public String getTableName(){
            return "books";
    }

}
