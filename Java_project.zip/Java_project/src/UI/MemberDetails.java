package UI;

import DB.Members;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

public class MemberDetails extends javax.swing.JFrame {

    public MemberDetails() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    private Map memberData = new HashMap<String, String>();

    private String mode;
    private int memberID;
    public void SetMode(String mode){
        this.mode = mode;
        if(mode.equals("new")){
            this.deleteMemberButton.setVisible(false);
        }else{
            this.titleLabel.setText("Update Member");
            this.saveButton.setText("Update Member");
        }
    }

    public void setMember(String memberID) throws SQLException{
        this.SetMode("view");
        Members members = new Members();
        ResultSet result = members.getResultSet("`id` = "+memberID+"");
        if(result.next()){
            this.memberIDInput.setText(Integer.toString(result.getInt("id")));
            this.nameInput.setText(result.getString("name"));
            this.emailInput.setText(result.getString("email"));
            this.phoneInput.setText(result.getString("phone"));
            this.addressInput.setText(result.getString("address"));
            this.idNumberInput.setText(result.getString("id_number"));
            if("NIC".equals(result.getString("id_type"))){
                this.nicTypeRadio.setSelected(true);
            }else{
                this.studentTypeRadio.setSelected(true);
            }
            this.birthdayInput.setText(result.getString("birthday"));
            this.genderSelector.setSelectedItem(result.getString("gender"));
            if(result.getInt("status") == 1){
                this.memberStatusCheckBox.setSelected(true);
            }else{
                this.memberStatusCheckBox.setSelected(false);
            }
        }
        this.memberID = result.getInt("id");

    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        idTypeGroup = new javax.swing.ButtonGroup();
        titleLabel = new javax.swing.JLabel();
        memberIDlabel = new javax.swing.JLabel();
        memberIDInput = new javax.swing.JTextField();
        lastNameLabel = new javax.swing.JLabel();
        nameInput = new javax.swing.JTextField();
        emnailLabel = new javax.swing.JLabel();
        emailInput = new javax.swing.JTextField();
        phonelabel = new javax.swing.JLabel();
        phoneInput = new javax.swing.JTextField();
        idNumberLabel = new javax.swing.JLabel();
        idNumberInput = new javax.swing.JTextField();
        idNumberLabel1 = new javax.swing.JLabel();
        nicTypeRadio = new javax.swing.JRadioButton();
        studentTypeRadio = new javax.swing.JRadioButton();
        addressLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        addressInput = new javax.swing.JTextArea();
        memberStatuslabel = new javax.swing.JLabel();
        memberStatusCheckBox = new javax.swing.JCheckBox();
        birthdayLabel = new javax.swing.JLabel();
        birthdayInput = new javax.swing.JFormattedTextField();
        genderLabel = new javax.swing.JLabel();
        genderSelector = new javax.swing.JComboBox<>();
        memberImgLabel = new javax.swing.JLabel();
        saveButton = new javax.swing.JButton();
        backToHomeButton = new javax.swing.JButton();
        deleteMemberButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        titleLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(0, 102, 102));
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Member Details");
        titleLabel.setAlignmentY(0.0F);

        memberIDlabel.setText("Membership Number");

        memberIDInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memberIDInputActionPerformed(evt);
            }
        });

        lastNameLabel.setText("Full Name");

        nameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameInputActionPerformed(evt);
            }
        });

        emnailLabel.setText("e-mail");

        emailInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailInputActionPerformed(evt);
            }
        });

        phonelabel.setText("Phone Number");

        phoneInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneInputActionPerformed(evt);
            }
        });

        idNumberLabel.setText("ID number");

        idNumberInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idNumberInputActionPerformed(evt);
            }
        });

        idNumberLabel1.setText("ID type");

        idTypeGroup.add(nicTypeRadio);
        nicTypeRadio.setSelected(true);
        nicTypeRadio.setText("NIC");
        nicTypeRadio.setActionCommand("");
        nicTypeRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nicTypeRadioActionPerformed(evt);
            }
        });

        idTypeGroup.add(studentTypeRadio);
        studentTypeRadio.setText("Student ID");
        studentTypeRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentTypeRadioActionPerformed(evt);
            }
        });

        addressLabel.setText("Address");

        addressInput.setColumns(20);
        addressInput.setRows(5);
        jScrollPane1.setViewportView(addressInput);

        memberStatuslabel.setText("Member Status");

        memberStatusCheckBox.setText("Active");
        memberStatusCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                memberStatusCheckBoxActionPerformed(evt);
            }
        });

        birthdayLabel.setText("Birthday (yyyy-dd-mm)");

        birthdayInput.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("y-MM-dd"))));
        birthdayInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                birthdayInputActionPerformed(evt);
            }
        });

        genderLabel.setText("Gender");

        genderSelector.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        memberImgLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/IMG/register_book.png"))); // NOI18N

        saveButton.setBackground(new java.awt.Color(214, 220, 221));
        saveButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        saveButton.setForeground(new java.awt.Color(0, 102, 102));
        saveButton.setText("Register Member");
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        backToHomeButton.setBackground(new java.awt.Color(221, 220, 214));
        backToHomeButton.setForeground(new java.awt.Color(153, 51, 0));
        backToHomeButton.setText("< Back to Manage Members");
        backToHomeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToHomeButtonActionPerformed(evt);
            }
        });

        deleteMemberButton.setBackground(new java.awt.Color(221, 220, 214));
        deleteMemberButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteMemberButton.setForeground(new java.awt.Color(255, 0, 0));
        deleteMemberButton.setText("Delete Member");
        deleteMemberButton.setActionCommand("");
        deleteMemberButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteMemberButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lastNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(emnailLabel)
                            .addComponent(phonelabel)
                            .addComponent(idNumberLabel)
                            .addComponent(addressLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(phoneInput)
                            .addComponent(emailInput)
                            .addComponent(nameInput)
                            .addComponent(jScrollPane1)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(idNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(memberIDlabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(memberIDInput, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(saveButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(backToHomeButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(idNumberLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(34, 34, 34)
                                    .addComponent(nicTypeRadio)
                                    .addGap(18, 18, 18)
                                    .addComponent(studentTypeRadio)
                                    .addGap(29, 29, 29))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(birthdayLabel)
                                    .addGap(12, 12, 12)
                                    .addComponent(birthdayInput, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(genderLabel)
                                    .addComponent(memberStatuslabel))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(memberStatusCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(genderSelector, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(memberImgLabel)
                        .addGap(16, 16, 16))
                    .addComponent(deleteMemberButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titleLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(memberIDlabel)
                    .addComponent(memberIDInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lastNameLabel)
                    .addComponent(nameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emnailLabel)
                    .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phonelabel)
                    .addComponent(phoneInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addressLabel)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idNumberLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idNumberLabel1)
                            .addComponent(nicTypeRadio)
                            .addComponent(studentTypeRadio))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(birthdayLabel)
                            .addComponent(birthdayInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(genderSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(genderLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(memberStatuslabel)
                            .addComponent(memberStatusCheckBox)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(memberImgLabel)))
                .addGap(18, 18, 18)
                .addComponent(saveButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(backToHomeButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteMemberButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void memberIDInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memberIDInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_memberIDInputActionPerformed

    private void nameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameInputActionPerformed

    private void emailInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailInputActionPerformed

    private void phoneInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneInputActionPerformed

    private void idNumberInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idNumberInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idNumberInputActionPerformed

    private void studentTypeRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentTypeRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentTypeRadioActionPerformed

    private void memberStatusCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_memberStatusCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_memberStatusCheckBoxActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
       if(!"".equals(this.memberIDInput.getText())){
        this.memberData.put("id", this.memberIDInput.getText());
       }
       this.memberData.put("name", this.nameInput.getText());
       this.memberData.put("email", this.emailInput.getText());
       this.memberData.put("phone", this.phoneInput.getText());
       this.memberData.put("id_number",this.idNumberInput.getText());
       if(this.nicTypeRadio.isSelected()){
           this.memberData.put("id_type","NIC");
       }else{
           this.memberData.put("id_type","Student");
       }
       if(!"".equals(this.birthdayInput.getText())){
            this.memberData.put("birthday", this.birthdayInput.getText());
       }
       this.memberData.put("gender", this.genderSelector.getSelectedItem().toString());
       if(this.memberStatusCheckBox.isSelected()){
           this.memberData.put("status","1");
       }else{
           this.memberData.put("status","0");

       }
       System.out.println(this.memberData);
       if("new".equals(this.mode)){
           this.newMember();
       }else{
           this.updateMember();
       }
        //going back to member mamagement
        ManageMembers manageMembers = new ManageMembers();
        manageMembers.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_saveButtonActionPerformed

    /**
     * Register new member
     */
    public void newMember(){
        Members members = new Members();
        members.insert(memberData);
        JOptionPane.showMessageDialog(null, "Member added successfully");
    }

    /**
     * Update member
     */
    public void updateMember(){
        Members members = new Members();
        members.update(memberData,this.memberID);
        JOptionPane.showMessageDialog(null, "Member updated successfully");
    }
    private void backToHomeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToHomeButtonActionPerformed
        ManageMembers manageMembers = new ManageMembers();
        manageMembers.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backToHomeButtonActionPerformed

    private void birthdayInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_birthdayInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_birthdayInputActionPerformed

    private void nicTypeRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nicTypeRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nicTypeRadioActionPerformed

    private void deleteMemberButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteMemberButtonActionPerformed
        int input = JOptionPane.showConfirmDialog(null, "Do you want to Delete this member?");
        // 0=yes, 1=no, 2=cancel
        if(input == 0){
            Members books = new Members();
            books.delete( this.memberID);

            //going back to member mamagement
            ManageMembers manageMembers = new ManageMembers();
            manageMembers.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_deleteMemberButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MemberDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MemberDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MemberDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MemberDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MemberDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea addressInput;
    private javax.swing.JLabel addressLabel;
    private javax.swing.JButton backToHomeButton;
    private javax.swing.JFormattedTextField birthdayInput;
    private javax.swing.JLabel birthdayLabel;
    private javax.swing.JButton deleteMemberButton;
    private javax.swing.JTextField emailInput;
    private javax.swing.JLabel emnailLabel;
    private javax.swing.JLabel genderLabel;
    private javax.swing.JComboBox<String> genderSelector;
    private javax.swing.JTextField idNumberInput;
    private javax.swing.JLabel idNumberLabel;
    private javax.swing.JLabel idNumberLabel1;
    private javax.swing.ButtonGroup idTypeGroup;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lastNameLabel;
    private javax.swing.JTextField memberIDInput;
    private javax.swing.JLabel memberIDlabel;
    private javax.swing.JLabel memberImgLabel;
    private javax.swing.JCheckBox memberStatusCheckBox;
    private javax.swing.JLabel memberStatuslabel;
    private javax.swing.JTextField nameInput;
    private javax.swing.JRadioButton nicTypeRadio;
    private javax.swing.JTextField phoneInput;
    private javax.swing.JLabel phonelabel;
    private javax.swing.JButton saveButton;
    private javax.swing.JRadioButton studentTypeRadio;
    private javax.swing.JLabel titleLabel;
    // End of variables declaration//GEN-END:variables
}
