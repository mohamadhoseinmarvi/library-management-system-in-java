
import UI.LoginForm;

public class MainClass {

    public static void main(String[] args) {
        System.out.println("Displaying the login form");
        LoginForm welcome = new LoginForm();
        welcome.setVisible(true);
    }

}
